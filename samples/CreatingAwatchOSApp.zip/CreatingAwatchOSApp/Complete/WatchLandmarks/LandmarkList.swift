import SwiftUI

struct Landmark: Identifiable, Decodable {
    let id: Int
    let name: String
    let park: String
    let state: String
    let imageName: String

    static let examples: [Landmark] = {
        guard let url = Bundle.main.url(forResource: "landmarks", withExtension: "json") else {
            preconditionFailure("Missing landmarks.json")
        }
        do {
            return try JSONDecoder().decode([Landmark].self, from: Data(contentsOf: url))
        } catch {
            preconditionFailure("Could not load landmarks: \(error)")
        }
    }()
}

struct LandmarkList: View {
    var body: some View {
        NavigationStack {
            List(Landmark.examples) { landmark in
                NavigationLink {
                    LandmarkDetail(landmark: landmark)
                } label: {
                    HStack {
                        Image(landmark.imageName)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 40, height: 40)
                            .clipShape(Circle())
                        Text(landmark.name)
                    }
                }
            }
            .navigationTitle("Landmarks")
        }
    }
}
