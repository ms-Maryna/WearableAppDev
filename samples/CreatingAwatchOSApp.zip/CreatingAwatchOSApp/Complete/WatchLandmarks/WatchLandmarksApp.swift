import SwiftUI

@main
struct WatchLandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            LandmarkList()
        }
    }
}
