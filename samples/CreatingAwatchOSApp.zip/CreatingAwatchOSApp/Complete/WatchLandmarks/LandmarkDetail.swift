import SwiftUI

struct LandmarkDetail: View {
    let landmark: Landmark

    var body: some View {
        ScrollView {
            VStack {
                Image(landmark.imageName)
                    .resizable()
                    .scaledToFit()
                Text(landmark.name)
                    .font(.headline)
                Text(landmark.park)
                Text(landmark.state)
                    .foregroundStyle(.secondary)
            }
        }
    }
}
